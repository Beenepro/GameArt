# OrlokGameAssets

Root folder for the Orlok Game Assets project. See /assets for asset subfolders.