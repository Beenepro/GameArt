# OrlokGameAssets/assets/player

This folder contains player sprite assets for the Orlok game project.