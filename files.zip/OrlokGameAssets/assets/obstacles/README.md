# OrlokGameAssets/assets/obstacles

Obstacle sprites used in the Orlok game (e.g., guards, rocks, bats).