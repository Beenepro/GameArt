# OrlokGameAssets/assets/fx

Visual effects for the Orlok game (e.g., magic, particles).