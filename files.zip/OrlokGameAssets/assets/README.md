# OrlokGameAssets/assets

Contains all game asset categories: player, obstacles, environment, and fx.