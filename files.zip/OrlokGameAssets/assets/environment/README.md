# OrlokGameAssets/assets/environment

Backgrounds and platforms for the Orlok game environment.